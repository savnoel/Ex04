"""List Utility Functions."""

__author__ = "730604481"


def all(numb: list[int], desire: int) -> bool: 
    """Given a list of ints, all should return a bool if the ints in the list are the same as the given int."""
    index: int = 0
    if len(numb) == 0:
        return False
    while len(numb) > index:  # While the index is less than the length of the list
        if numb[index] == desire:  # If the number in the list is equal to the user's inputted number
            index += 1
        else:
            return False
    return True

    
def max(numb2: list[int]) -> int:
    """Given a list of ints, max should return the largest in the List."""
    idx: int = 0 
    if len(numb2) == 0:  # if given an empty list
        raise ValueError("max()) arg is an empty List") 
    else:  # the list isn't empty
        x: int = numb2[idx]
        while len(numb2) > idx + 1:
            if x < numb2[idx + 1]:
                x = numb2[idx + 1]
            idx += 1
        return x
    

def is_equal(numb3: list[int], numb4: list[int]) -> bool:
    """Given two lists of ints, returns True if every element at every index is ==, return False otherwise."""
    i: int = 0 
    if len(numb3) != len(numb4):
        return False
    while i < len(numb3):  # While the length of the lists are equal, and the indexes are less than the lengths of both numb3 and numb4
        if numb3[i] == numb4[i]:  # If the numbers at the same indexes of both list are equal
            i += 1
        else:
            return False
    return True
    
    
